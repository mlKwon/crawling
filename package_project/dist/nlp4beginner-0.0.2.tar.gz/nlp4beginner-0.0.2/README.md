# Example Of nlp4beginner

- this is sample package of nlp for beginners.
- This package will be updated soon for all users